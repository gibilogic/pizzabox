DROP TABLE IF EXISTS `#__pizzabox_containers`;
DROP TABLE IF EXISTS `#__pizzabox_parts`;
DROP TABLE IF EXISTS `#__pizzabox_flavours`;
DROP TABLE IF EXISTS `#__pizzabox_orders`;
DROP TABLE IF EXISTS `#__pizzabox_orders_parts`;
DROP TABLE IF EXISTS `#__pizzabox_status`;
