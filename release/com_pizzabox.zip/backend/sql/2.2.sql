ALTER TABLE  `#__pizzabox_orders` ADD  `name` VARCHAR( 50 ) NULL AFTER  `delivery`
