CREATE TABLE  `#__pizzabox_addresses` ADD  `address_id` INT(11) NULL AFTER  `user_id`
