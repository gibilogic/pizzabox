<?php defined('_JEXEC') or die('The way is shut!');
/**
 * @version		    $Id: controllers/flavours.php 2012-08-14 13:26:00Z zanardi $
 * @package		    GiBi PizzaBox
 * @author        GiBiLogic snc
 * @authorEmail   info@gibilogic.com
 * @authorUrl     http://www.gibilogic.com
 * @copyright	    Copyright (C) 2011-2012 GiBiLogic. All rights reserved.
 * @license		    GNU/GPL v2 or later
 */

require_once('abstract.php');

class PizzaboxControllerFlavours extends PizzaboxControllerAbstract
{

}
